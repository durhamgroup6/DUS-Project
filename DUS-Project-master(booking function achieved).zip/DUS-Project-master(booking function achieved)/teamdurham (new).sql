-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2019 at 01:05 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `teamdurham`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `BookingID` int(11) NOT NULL,
  `EventID` int(20) NOT NULL,
  `UserID` int(20) NOT NULL,
  `StartTime` datetime NOT NULL,
  `EndTime` datetime NOT NULL,
  `Price` float NOT NULL,
  `FacilityID` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`BookingID`, `EventID`, `UserID`, `StartTime`, `EndTime`, `Price`, `FacilityID`) VALUES
(1, 0, 0, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 0, 0),
(2, 0, 0, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 0, 0),
(3, 0, 3, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 5, 1),
(4, 0, 3, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 5.4, 1),
(5, 0, 3, '2019-05-12 08:00:00', '2019-05-12 09:00:00', 5.4, 1),
(6, 0, 3, '2019-05-12 09:00:00', '2019-05-12 10:00:00', 5.4, 1),
(7, 0, 3, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 5.4, 1),
(8, 0, 3, '1970-01-01 01:33:39', '1970-01-01 02:33:39', 5.4, 1),
(9, 0, 3, '2019-05-12 07:00:00', '2019-05-12 08:00:00', 5.4, 1),
(10, 0, 3, '1970-01-01 01:00:00', '1970-01-01 02:00:00', 5.4, 1),
(11, 0, 3, '1970-01-01 01:00:00', '1970-01-01 02:00:00', 5.4, 1),
(12, 0, 0, '0000-00-00 00:00:00', '1970-01-01 02:00:00', 0, 0),
(13, 0, 0, '0000-00-00 00:00:00', '1970-01-01 02:00:00', 0, 0),
(14, 0, 3, '2019-05-12 10:00:00', '2019-05-12 11:00:00', 5.4, 1),
(15, 0, 3, '2019-05-12 11:00:00', '2019-05-12 12:00:00', 5.4, 1),
(16, 0, 3, '2019-05-12 12:00:00', '2019-05-12 13:00:00', 5.4, 1),
(17, 0, 3, '2019-05-12 13:00:00', '2019-05-12 14:00:00', 5.4, 1),
(24, 0, 3, '2019-05-12 20:00:00', '2019-05-12 21:00:00', 5.4, 1),
(25, 0, 3, '2019-05-12 20:00:00', '2019-05-12 21:00:00', 5.4, 1),
(26, 0, 3, '2019-05-12 20:00:00', '2019-05-12 21:00:00', 5.4, 1),
(27, 0, 3, '2019-05-12 20:00:00', '2019-05-12 21:00:00', 5.4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `EventID` int(11) NOT NULL,
  `EventName` text CHARACTER SET utf8 NOT NULL,
  `TrainerID` int(11) NOT NULL,
  `Capacity` int(11) NOT NULL,
  `Description` longtext CHARACTER SET utf8 NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime NOT NULL,
  `FacilityID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

INSERT INTO `event` (`EventID`, `EventName`, `TrainerID`, `Capacity`, `Description`, `StartDate`, `EndDate`, `FacilityID`) VALUES
(1, 'dance', 2, 3, 'love u', '2019-05-09 00:00:00', '2019-05-13 00:00:00', 2);

-- --------------------------------------------------------

--
-- Table structure for table `facility`
--

CREATE TABLE `facility` (
  `FacilityID` int(11) NOT NULL,
  `FacilityName` text NOT NULL,
  `Description` text NOT NULL,
  `Price` int(11) NOT NULL,
  `Capacity` int(10) NOT NULL,
  `Availability` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `facility`
--

INSERT INTO `facility` (`FacilityID`, `FacilityName`, `Description`, `Price`, `Capacity`, `Availability`) VALUES
(1, 'Squash Courts', 'Squash Courts: &pound6 per court, per hour.', 6, 5, 1),
(2, 'Aerobics room', 'A mirrored studio is avaliable for group classes such as dance, yoga and pilates. This space can also be used for presentations and functions.\r\n\r\nAerobics Room - &pound20.00 per hour', 20, 20, 1),
(3, 'Tennis', 'Tennis (Tarmac) - &pound10.00 per court per hour', 10, 20, 1),
(4, 'Athletics Track', 'Track - &pound2.00 per person\r\n\r\nTrack (sole use) - &pound30.00 per hour', 30, 20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL,
  `Password` text NOT NULL,
  `Email` text NOT NULL,
  `Phone` text NOT NULL,
  `Role` enum('user','trainer','admin') NOT NULL DEFAULT 'user',
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `resetpasswordtime` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Password`, `Email`, `Phone`, `Role`, `Firstname`, `Lastname`, `resetpasswordtime`) VALUES
(2, '$2y$10$.wfdFWUfsvO7QQ0v6ScBQuXwXDxy5IUDMMxLh6gd8XAET41XnjaLS', '414454879@qq.com', '7851666865', 'user', 'z', 'chen', 0),
(3, '$2y$10$DIUIRhmJ44GlwRmmnUzA0.sNQm6kkPtDKke3LFqW3nGvyY3IgVrBG', '123@qq.com', '123', 'user', 'a', 'chen', 0),
(4, '$2y$10$B6213fivCLUWAFvrGYOPKOkfC2VdkGfY11kxsCTm7GkGDSDNXfkTq', '649965979@qq.com', '11223344', 'user', 'wanyu', 'hong', 1557584318);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD PRIMARY KEY (`BookingID`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`EventID`);

--
-- Indexes for table `facility`
--
ALTER TABLE `facility`
  ADD PRIMARY KEY (`FacilityID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booking`
--
ALTER TABLE `booking`
  MODIFY `BookingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `EventID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facility`
--
ALTER TABLE `facility`
  MODIFY `FacilityID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
