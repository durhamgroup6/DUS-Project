<?php
include 'database.php';
session_start();
$userId = $_SESSION['user']['UserID'];
$facilityName = filter_input(INPUT_POST, 'facility', FILTER_SANITIZE_STRING);
$startTime = filter_input(INPUT_POST, 'startTime', FILTER_SANITIZE_STRING);
$startTime = date('Y-m-d H:i:s', strtotime($startTime));//formatting it a bit
$howLong = filter_input(INPUT_POST, 'howLong', FILTER_SANITIZE_STRING);
$isMember = filter_input(INPUT_POST, 'isMember', FILTER_SANITIZE_STRING);

$check_startTime = date('H:i:s',strtotime($startTime));
if($check_startTime < '07-00-00'){// check if the start time picked is earlier than standard open time
    ?>
    <script>
        window.alert("Sorry, you cannot pick a time earlier than standard open time(7.00 am).");
        history.go(-1);
    </script>
    <?php
    die();
}
$check_endTime = date('H:i:s',strtotime("+".$howLong." hour", strtotime($startTime)));
//echo $check_endTime;
if($check_endTime > '22-00-01' or $check_endTime < '07-00-00'){// check if the end time picked is latter than standard close time
    ?>
    <script>
        window.alert("Sorry, you cannot pick a time later than standard close time(10.00 pm).");
        history.go(-1);
    </script>
    <?php
    die();
}


$stmt=$pdo->query("SELECT * FROM facility WHERE FacilityName='".$facilityName."';");
$facility=$stmt->fetch(PDO::FETCH_ASSOC);
$facilityId = $facility['FacilityID'];// getting facilityID by facilityName
$price = $facility['Price'];// getting the price per hour
$totalPrice = $price*$howLong;
$capacity = $facility['Capacity'];
if($isMember == 1){
    $price = 0.9*$price;
}

$stmt=$pdo->query("SELECT * FROM event WHERE FacilityID='".$facilityId."' AND StartDate <= '".$startTime."' AND EndDate >= '".$startTime."';");// find the events that are using the same facility at the same time
$event_withinTime = $stmt->fetch(PDO::FETCH_ASSOC);
if(!empty($event_withinTime)){
    ?>
    <script>
        window.alert("Sorry, this facility is occupied by event(s) during your booking period, please check the available time from the calendar and book again!");
        history.go(-1);
    </script>
    <?php
    die();
}else{
    for ($x=1; $x<=$howLong; $x++){
        $nextHour = date('Y-m-d H:i:s',strtotime("+1 hour", strtotime($startTime)));// one hour later of the start time
        $stmt=$pdo->query("SELECT COUNT(BookingID) AS currentBookings FROM booking WHERE StartTime='".$startTime."' AND EndTime='".$nextHour."';");
        $count = $stmt->fetch(PDO::FETCH_ASSOC);
        $currentBookings = $count['currentBookings'];
        if($currentBookings >= $capacity){
            ?>
            <script>
                window.alert("Sorry, this facility is full booked from <?php echo $startTime; ?> to <?php echo $nextHour; ?>");
                history.go(-1);
            </script>
            <?php
            die();
        }else{
            $insert_into_booking = "INSERT INTO booking (UserID, StartTime, EndTime, Price, FacilityID) VALUES ('".$userId."', '".$startTime."', '".$nextHour."', '".$price."', '".$facilityId."');";
            $pdo->exec($insert_into_booking);
            $startTime = $nextHour;
        }
    }
    ?>
    <script>
        window.alert("You have booked the facility!");
        location.href="index.php";
    </script>
    <?php
    die();
}
?>


