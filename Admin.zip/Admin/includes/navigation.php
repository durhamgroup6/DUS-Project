<?php
?>
<div class="sidebar-menu">
    <div class="sidebar-header">
        <div class="logo">
            <a href="index.php"><h2 style="color:white;">DURHAM</h2></a>
        </div>
    </div>
    <div class="main-menu">
        <div class="menu-inner">
            <nav>
                <ul class="metismenu" id="menu">
                    <li><a href="index.php"><i class="ti-map-alt"></i> <span>View Users</span></a></li>
                    <li>
                        <a href="javascript:void(0)" aria-expanded="true"><i class="fa fa-align-left"></i> <span>Facilities</span></a>
                        <ul class="collapse">
                            <li><a href="addFacilities.php">Add Facilities</a></li>
                            <li><a href="viewFacilties.php">View Facilities</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
