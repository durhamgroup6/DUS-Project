<?php
function sendmail($email,$subject, $body){
    require '../User/php/PHPMailer.php';

    $mail = new PHPMailer;

    //$mail->SMTPDebug = 0;                               // Enable verbose debug output

    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.qq.com';  // Specify main and backup SMTP servers. 这里改成smtp.gmail.com
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = '649965979@qq.com';                 // SMTP username 这里改成自己的gmail邮箱，最好新注册一个，因为后期设置会导致安全性降低
    $mail->Password = 'xnwisvsbeuxnbbdg';                           // SMTP password 这里改成对应邮箱密码
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port =25 ;                                    // TCP port to connect to

    $mail->setFrom('admin@teamdurhum.com');
    $mail->addAddress($email);     // Add a recipient 这里改成用于接收邮件的测试邮箱 // Name is optional
    $mail->isHTML(true);                                  // Set email format to HTML

    $mail->Subject = $subject;
    $mail->Body    = $body;
//    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';
    $rs = $mail->send();
    return $rs;
//    if(!$mail->send()) {
//        echo  'Message could not be sent.';
//        echo 'Mailer Error: ' . $mail->ErrorInfo;
//    } else {
//        echo 'Message has been sent';
//    }

}
?>