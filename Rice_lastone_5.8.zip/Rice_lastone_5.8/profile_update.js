$(document).ready(function() {

    $('.update').on('click', function(e) {
        console.log("1233");
        $.ajax({
            url:"ajax_profile_update.php",
            type: 'post',
            data: {'id': this.id},
            success: got_data,
            fail: not_got_data,
        });
    });
});

function got_data(data){
    $('.profile_update').html(data);
}

function not_got_data(){
    alert("There's something wrong");
}
