<?php
/**
 * Created by PhpStorm.
 * User: 陈子峰
 * Date: 2019/5/8
 * Time: 20:16
 */
$pdo = new PDO('mysql:host=127.0.0.1;dbname=teamdurham','root');
?>