<?php
/**
 * Created by PhpStorm.
 * User: 陈子峰
 * Date: 2019/5/8
 * Time: 20:48
 */
session_start();
if(empty($_SESSION)){
    header('Location: login.html');
    die("You have not logged in!");
}else{
    echo $_SESSION["user"]['Firstname']."!!!";
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home Page</title>
    <link rel="stylesheet" type="text/css" href="styles.css">

    <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js">
    </script>
    <script src="profile_update.js"></script>
</head>

<div class="profile">
    <p>Your profile</p>
    <table border="1" class="profile_update">
        <tr>
            <th>First Name</th>
            <th><?php echo $_SESSION["user"]['Firstname'] ?></th>
            <td><button id='firstname' class='update'>Change</button></td>
        </tr>
        <tr>
            <th>Last Name</th>
            <th><?php echo $_SESSION["user"]['Lastname'] ?></th>
            <td><button id='lastname' class='update'>Change</button></td>
        </tr>
        <tr>
            <th>Phone Number</th>
            <th><?php echo $_SESSION["user"]['Phone'] ?></th>
            <td><button id='phone' class='update'>Change</button></td>
        </tr>
</div>
</html>