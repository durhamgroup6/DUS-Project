<?php
/**
 * Created by PhpStorm.
 * User: 陈子峰
 * Date: 2019/5/8
 * Time: 21:36
 */
$changing_field = $_REQUEST['id'];

echo "<form class='update_submit' action='update_submit.php' method='post'>
      New $changing_field<input type='text' name='changed'>
      <input type='hidden' name='changing' value='$changing_field'>
      <input type='submit'>
      </form>";