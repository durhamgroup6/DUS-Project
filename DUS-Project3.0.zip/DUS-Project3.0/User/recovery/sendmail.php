<?php
include_once("../database.php");

$email = stripslashes(trim($_POST['mail']));

$sql = "select * from user where Email='$email'";
$query = $pdo->query($sql);
$row = $query->fetch(PDO::FETCH_ASSOC);
if ($row ==null) {//this email does not register！
    echo 'noreg';
    exit;
} else {
    $getpasstime = time();
    $uid = $row['UserID'];
    $token = md5($uid . $row['Email'] . $row['Password']);
    $url = "http://localhost:63342/DUS-Project2.0/User/recovery/reset.php?_ijt=ur5g5i1aa1rbh4nam0pdj1um0e?reset=yes&token=" . $token . "&email=" . $email;
    $time = date('Y-m-d H:i');
    $result = sendmail($time, $email, $url);
    if ($result==1) {//邮件发送成功
        $msg = 'The System has sent a email for you,check your email and reset your password please！';
        //update reset password time
        $sql = "UPDATE user SET resetpasswordtime='$getpasstime' WHERE UserID='$uid'";
        $result=$pdo->query($sql);
    } else {
        $msg = $result;
    }
    echo $msg;
}

function sendmail($time, $email, $url) {
    include_once("../php/smtp.class.php");
    $smtpserver = "smtp.qq.com"; //SMTP server
    $smtpserverport = 25; //SMTP server port
    $smtpusermail = "649965979@qq.com"; //SMTP server's email
    $smtpuser = "649965979@qq.com"; //SMTP server's account
    $smtppass = "xnwisvsbeuxnbbdg"; //SMTP server's password
    $smtp = new Smtp($smtpserver, $smtpserverport, true, $smtpuser, $smtppass); //true means using auth.
    $emailtype = "html"; //email type，text；web：HTML
    $smtpemailto = $email;
    $smtpemailfrom = $smtpusermail;
    $emailsubject = "Durham Sport Online Booking - Reset Password";
    $emailbody = "Dear " . $email . "：you are in " . $time . " submit a request of reseting password. Please click the link to reset password（valid for 24 hours).".$url." If you cannot click this link, please copy it enter your website address. If you do not submit this request,ignore this email please.";
    $rs = $smtp->sendmail($smtpemailto, $smtpemailfrom, $emailsubject, $emailbody, $emailtype);
    return $rs;
}

?>