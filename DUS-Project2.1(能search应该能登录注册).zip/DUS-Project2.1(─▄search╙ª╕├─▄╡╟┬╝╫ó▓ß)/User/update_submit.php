<?php
/**
 * Created by PhpStorm.
 * User: 陈子峰
 * Date: 2019/5/8
 * Time: 21:48
 */

echo 123;
//require_once 'database.php';
//session_start();
//$userid = $_SESSION['user']['UserID'];
//$changing_field = filter_input(INPUT_POST, 'changing', FILTER_SANITIZE_STRING);
//$changed = filter_input(INPUT_POST, 'changing', FILTER_SANITIZE_STRING);
//
//$update = "UPDATE user SET '".$changing_field."'= '".$changed."' WHERE UserID = '".$userid."'";
//$pdo->exec($update);
//?>
<!--<script>-->
<!--    window.alert("Everything recorded!");-->
<!--    location.href="index_foruser.php";-->
<!--</script>-->
