<?php
include_once('database.php');//连接数据库

$sql = "select * from event";
$result = $pdo->query($sql);
while($row = $result->fetch(PDO::FETCH_ASSOC)){
    $allday = $row['allday'];
    $is_allday = $allday==1?true:false;
    $data[] = array(
        'id' => $row['EventID'],//事件id
        'title' => $row['EventName'],//事件标题
        'allday' => $is_allday, //是否为全天事件
        'start' => $row['StartTime'],//事件开始时间
        'end' => $row['EndTime'],//结束时间
    );
}
echo json_encode($data);
?>