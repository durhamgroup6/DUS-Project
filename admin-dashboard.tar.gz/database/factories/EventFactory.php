<?php

$factory->define(App\Event::class, function (Faker\Generator $faker) {
    return [
        "event_name" => $faker->name,
        "trainer_name_id" => factory('App\User')->create(),
        "cabacity" => $faker->randomNumber(2),
        "start_date" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "end_date" => $faker->date("d/m/Y H:i:s", $max = 'now'),
        "facility_name_id" => factory('App\Facility')->create(),
        "price" => $faker->randomNumber(2),
        "description" => $faker->name,
    ];
});
