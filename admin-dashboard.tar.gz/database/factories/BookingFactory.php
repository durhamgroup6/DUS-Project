<?php

$factory->define(App\Booking::class, function (Faker\Generator $faker) {
    return [
        "user_name_id" => factory('App\User')->create(),
        "event_name_id" => factory('App\Event')->create(),
        "facility_name_id" => factory('App\Facility')->create(),
        "quantity" => $faker->randomNumber(2),
        "price" => $faker->randomNumber(2),
        "booking_date" => $faker->date("d/m/Y", $max = 'now'),
    ];
});
