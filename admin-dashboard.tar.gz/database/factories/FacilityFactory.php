<?php

$factory->define(App\Facility::class, function (Faker\Generator $faker) {
    return [
        "facility_name" => $faker->name,
        "availbility" => $faker->randomNumber(2),
        "description" => $faker->name,
        "capacity" => $faker->randomNumber(2),
        "facility_email" => $faker->safeEmail,
        "facility_phone" => $faker->name,
    ];
});
