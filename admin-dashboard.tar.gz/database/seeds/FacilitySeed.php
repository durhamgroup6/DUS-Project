<?php

use Illuminate\Database\Seeder;

class FacilitySeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            
            ['id' => 1, 'facility_name' => 'Fitness Suite', 'picture' => '/tmp/phpVxTWDt', 'availbility' => 1, 'description' => '<p style="text-align: justify;">The fitness suite is fully air conditioned and benefits from a wide variety of machines and equipment including Technogym resistance machines, cable systems, free weights, cardio vascular machines, TRX suspension training system, ViPR trainers and medicine balls, as well as foam rollers and exercise balls. We also have a chilled water dispenser and large screen TVs.</p>

<p style="text-align: justify;">We have a number of fully qualified and knowledgeable members of staff who can assist with any of your needs and provide guidance with exercises or workout plans.</p>

<p style="text-align: justify;">You will also benefit from free parking and on-site change/shower facilities.</p>

<p style="text-align: justify;"><strong>Opening Times:</strong></p>

<p style="text-align: justify;">Monday to Friday &ndash; 7.00 am &ndash; 10.00 pm (last entry, 9.15 pm)<br />
Saturday &amp; Sunday &ndash; 9.00 am &ndash; 6.00 pm (last entry, 5.15 pm)</p>
', 'adderss_address' => 'Durham DH1 3SE, UK', 'adderss_latitude' => 54.7675965, 'adderss_longitude' => -1.559469, 'capacity' => null, 'facility_email' => 'Fitness.suite@dur.ac.uk', 'facility_phone' => '01913342178',],
            ['id' => 2, 'facility_name' => 'Maiden Castle Physiotherapy', 'picture' => '/tmp/phpdPmkN0', 'availbility' => 1, 'description' => '<p><strong>Who are we and what can we do for you?</strong></p>

<p>Maiden Castle Physiotherapy (MCP) is a friendly and experienced team offering services to the athletes of Team Durham and the surrounding area. Based at the Graham Sports Centre in Maiden Castle, our specialist team offer physiotherapy for a wide range of musculoskeletal conditions including sports injuries, back, neck or joint or muscle pains or sports injuries.</p>

<p>Our team of experienced state registered NHS physiotherapists will assess and provide tailored treatment programmes to help get you back on track, achieve your overall fitness goals and offer preventative advice to help you stay pain free.</p>

<p>Physiotherapy assessment/treatment 3<em>0 minutes</em>&nbsp;<strong>&pound;30</strong></p>

<p>Discounted rate for Durham University Staff&nbsp;<strong>&pound;28</strong></p>

<p>Discounted for Durham University Students&nbsp;<strong>&pound;24</strong></p>

<p>Sports massage&nbsp;<em>30 minutes</em>&nbsp;<strong>&pound;25</strong></p>

<p>Book your appointment&nbsp;through the Graham Sports Centre reception today</p>

<p>Daytime and evening appointments available</p>

<p><strong>Our opening hours are:</strong></p>

<p><strong>Monday</strong>&nbsp;afternoon/evening</p>

<p><strong>Tuesday</strong>&nbsp;afternoon/evening</p>

<p><strong>Wednesday</strong>&nbsp;all day</p>

<p><strong>Thursday</strong>&nbsp;afternoon/evening</p>

<p><strong>Friday</strong>&nbsp;morning</p>

<p><strong>If you book an appointment with us:</strong></p>

<ul>
	<li>During physiotherapy and massage appointments you may be asked to remove items&nbsp;of clothing to allow for assessment and treatment of an area and adjacent joints.</li>
	<li>For screening please wear shorts, trainers and a sports top.</li>
	<li>Athletes under 16 will need to be accompanied by a chaperone.</li>
	<li>If you have a preference for a male or female therapist please make the request when booking your appointment.</li>
</ul>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => '0191 334 2178',],
            ['id' => 3, 'facility_name' => 'Squash Courts', 'picture' => null, 'availbility' => 1, 'description' => '<p>Squash Courts: &pound;6 per court, per hour.</p>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 4, 'facility_name' => 'Sports Hall', 'picture' => '/tmp/php3MmB86', 'availbility' => 1, 'description' => '<p style="text-align: justify;">There are multiple activites that take place in the sports hall.</p>

<p style="text-align: justify;">Squash: &pound;6.00 per court per hour</p>

<p style="text-align: justify;">Badminton: &pound;11.00 per court per hour</p>

<p style="text-align: justify;">Basketball: &pound;27.50 per hour</p>

<p style="text-align: justify;">Volleyball: &pound;27.50 per hour</p>

<p style="text-align: justify;">5 a side: &pound;55.00 per hour</p>

<p style="text-align: justify;">Netball: &pound;55.00 per hour</p>

<p style="text-align: justify;">Cricket Nets: &pound;60.00 per hour</p>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 5, 'facility_name' => 'Artificial pitches', 'picture' => '/tmp/phpbUpljy', 'availbility' => 1, 'description' => '<p><span style="font-family:arial,helvetica,sans-serif"><strong>Water-based Astro -</strong>&nbsp;(hockey)</span></p>

<p><span style="font-family:arial,helvetica,sans-serif">Staff/Student:</span></p>

<ul>
	<li><span style="font-family:arial,helvetica,sans-serif">Half pitch - &pound;20 per hour</span></li>
	<li><span style="font-family:arial,helvetica,sans-serif">Full pitch &pound;40 per hour</span></li>
</ul>

<p><span style="font-family:arial,helvetica,sans-serif">Public:</span></p>

<ul>
	<li><span style="font-family:arial,helvetica,sans-serif">Half pitch &pound;40 per hour</span></li>
	<li><span style="font-family:arial,helvetica,sans-serif">Full pitch &pound;80 per hour</span></li>
</ul>

<p><span style="font-family:arial,helvetica,sans-serif"><strong>Rubber Crumbs</strong></span></p>

<p><span style="font-family:arial,helvetica,sans-serif">Staff/Student:</span></p>

<ul>
	<li>
	<p><span style="font-family:arial,helvetica,sans-serif">Half pitch &pound;20 per hour</span></p>
	</li>
	<li><span style="font-family:arial,helvetica,sans-serif">Full pitch &pound;40 per hour</span></li>
</ul>

<p><span style="font-family:arial,helvetica,sans-serif">Public:</span></p>

<ul>
	<li><span style="font-family:arial,helvetica,sans-serif">Half pitch &pound;40 per hour</span></li>
	<li><span style="font-family:arial,helvetica,sans-serif">Full pitch &pound;80 per hour</span></li>
</ul>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 6, 'facility_name' => 'Ergo Gallery', 'picture' => null, 'availbility' => 1, 'description' => '<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Public:</span></p>

<ul>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Full Room: &pound;35 per hour</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">If a coach is required the hourly rate for a coach is &pound;15 per hour</span></p>
	</li>
</ul>

<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Staff/Students:</span></p>

<ul>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Full Room: &pound;30 per hour</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">If a coach is required the hourly rate for a coach is &pound;15 per hour</span></p>
	</li>
</ul>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 7, 'facility_name' => 'Rowing Tank', 'picture' => '/tmp/phpbRv3Ib', 'availbility' => 1, 'description' => '<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Public:</span></p>

<ul>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Static water training: &pound;35</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Moving water training: &pound;45</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">If a coach is required the hourly rate for a coach is &pound;15 per hour</span></p>
	</li>
</ul>

<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Staff/Student:</span></p>

<ul>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Static water training: &pound;30</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Moving water training: &pound;40</span></p>
	</li>
	<li>
	<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">If a coach is required the hourly rate for a coach is &pound;15 per hour</span></p>
	</li>
</ul>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 8, 'facility_name' => 'Outdoor Facilities', 'picture' => '/tmp/phpOL1rAU', 'availbility' => 1, 'description' => '<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Cricket (Artificial Wicket) - &pound;60.00</span></p>

<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Cricket (Grass Wicket) - 20 overs &pound;130&nbsp;<br />
20+ overs &pound;160.00</span></p>

<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Footbal/Rugby Pitch (Grass) - &pound;50 per hour</span></p>

<p style="text-align: justify;"><span style="font-family:arial,helvetica,sans-serif">Tennis (Tarmac) - &pound;10.00 per court per hour<br />
<br />
Netball (Tarmac) - &pound;10.00 per court per hour<br />
<br />
Track - &pound;2.00 per person<br />
<br />
Track (sole use) - &pound;30.00 per hour</span></p>
', 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 9, 'facility_name' => 'Rubber Crumbs', 'picture' => null, 'availbility' => null, 'description' => null, 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],
            ['id' => 10, 'facility_name' => 'Athletics Track', 'picture' => null, 'availbility' => 1, 'description' => null, 'adderss_address' => '', 'adderss_latitude' => 0, 'adderss_longitude' => 0, 'capacity' => null, 'facility_email' => null, 'facility_phone' => null,],

        ];

        foreach ($items as $item) {
            \App\Facility::create($item);
        }
    }
}
