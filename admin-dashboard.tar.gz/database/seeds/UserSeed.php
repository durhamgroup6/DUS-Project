<?php

use Illuminate\Database\Seeder;

class UserSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $items = [
            
            ['id' => 1, 'name' => 'Admin', 'email' => 'admin@admin.com', 'password' => '$2y$10$I0nW/HXSOPdzgUInPLH1UOzl1hN6FU7JeKpaYiRYTzE5meSyBbkEu', 'role_id' => 1, 'remember_token' => '', 'phone' => null,],
            ['id' => 2, 'name' => 'member1', 'email' => 'member1@m.com', 'password' => '$2y$10$gBTxnc.Y7b9OesuuoQgSUewE0jwa4kt4oB4cOoOX5Bo7EHZSwVQi2', 'role_id' => 2, 'remember_token' => null, 'phone' => 123456,],
            ['id' => 3, 'name' => 'member2', 'email' => 'member2@m.com', 'password' => '$2y$10$5Y89hTRKn7PtnTdKM4ByMuZ893o6lM09zZ.pZ/XF.RGORqlY0Tn1G', 'role_id' => 2, 'remember_token' => null, 'phone' => 123456,],
            ['id' => 4, 'name' => 'member3', 'email' => 'member3@m.com', 'password' => '$2y$10$EXgDMwlCnVa3CQ/PfhmrZuLB/h0drqC1dkSULdn8MX7Ol0XJmJapu', 'role_id' => 2, 'remember_token' => null, 'phone' => 123456,],
            ['id' => 5, 'name' => 'trainer1', 'email' => 'trainer1@t.com', 'password' => '$2y$10$9qpEjUYUwEqdlEYNwzGRz.y0FutKSWeWllRfYYAIlMILuOCJ2q9ji', 'role_id' => 3, 'remember_token' => null, 'phone' => 123123,],
            ['id' => 6, 'name' => 'trainer2', 'email' => 'trainer2@t.com', 'password' => '$2y$10$viFJS46712lPTj5H6z7YQeixoUNKndnAKv7dflRxWwosBvtHKZaoC', 'role_id' => 3, 'remember_token' => null, 'phone' => 123123,],

        ];

        foreach ($items as $item) {
            \App\User::create($item);
        }
    }
}
