<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1557457477FacilitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('facilities', function (Blueprint $table) {
            if(Schema::hasColumn('facilities', 'description')) {
                $table->dropColumn('description');
            }
            if(Schema::hasColumn('facilities', 'capacity')) {
                $table->dropColumn('capacity');
            }
            
        });
Schema::table('facilities', function (Blueprint $table) {
            
if (!Schema::hasColumn('facilities', 'description')) {
                $table->text('description')->nullable();
                }
if (!Schema::hasColumn('facilities', 'adderss_address')) {
                $table->string('adderss_address')->nullable();
                $table->double('adderss_latitude')->nullable();
                $table->double('adderss_longitude')->nullable();
                }
if (!Schema::hasColumn('facilities', 'capacity')) {
                $table->integer('capacity')->nullable();
                }
if (!Schema::hasColumn('facilities', 'facility_email')) {
                $table->string('facility_email')->nullable();
                }
if (!Schema::hasColumn('facilities', 'facility_phone')) {
                $table->integer('facility_phone')->nullable();
                }
if (!Schema::hasColumn('facilities', 'opeaing_hours')) {
                $table->datetime('opeaing_hours')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('facilities', function (Blueprint $table) {
            $table->dropColumn('description');
            $table->dropColumn('adderss_address');
            $table->dropColumn('adderss_latitude');
            $table->dropColumn('adderss_longitude');
            $table->dropColumn('capacity');
            $table->dropColumn('facility_email');
            $table->dropColumn('facility_phone');
            $table->dropColumn('opeaing_hours');
            
        });
Schema::table('facilities', function (Blueprint $table) {
                        $table->string('description')->nullable();
                $table->integer('capacity')->nullable();
                
        });

    }
}
