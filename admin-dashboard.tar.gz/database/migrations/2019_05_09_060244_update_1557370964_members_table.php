<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1557370964MembersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('members', function (Blueprint $table) {
            
if (!Schema::hasColumn('members', 'first_name')) {
                $table->string('first_name');
                }
if (!Schema::hasColumn('members', 'last_name')) {
                $table->string('last_name');
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('members', function (Blueprint $table) {
            $table->dropColumn('first_name');
            $table->dropColumn('last_name');
            
        });

    }
}
