<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5cd4e5c50366eRelationshipsToBookingTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('bookings', function(Blueprint $table) {
            if (!Schema::hasColumn('bookings', 'user_name_id')) {
                $table->integer('user_name_id')->unsigned()->nullable();
                $table->foreign('user_name_id', '302661_5cd4d8ab8c6df')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('bookings', 'event_name_id')) {
                $table->integer('event_name_id')->unsigned()->nullable();
                $table->foreign('event_name_id', '302661_5cd4d8aba77df')->references('id')->on('events')->onDelete('cascade');
                }
                if (!Schema::hasColumn('bookings', 'facility_name_id')) {
                $table->integer('facility_name_id')->unsigned()->nullable();
                $table->foreign('facility_name_id', '302661_5cd4d8abc24e1')->references('id')->on('facilities')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('bookings', function(Blueprint $table) {
            
        });
    }
}
