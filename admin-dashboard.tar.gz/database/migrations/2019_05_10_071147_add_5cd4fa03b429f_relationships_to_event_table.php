<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Add5cd4fa03b429fRelationshipsToEventTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('events', function(Blueprint $table) {
            if (!Schema::hasColumn('events', 'trainer_name_id')) {
                $table->integer('trainer_name_id')->unsigned()->nullable();
                $table->foreign('trainer_name_id', '302660_5cd4d545051d6')->references('id')->on('users')->onDelete('cascade');
                }
                if (!Schema::hasColumn('events', 'facility_name_id')) {
                $table->integer('facility_name_id')->unsigned()->nullable();
                $table->foreign('facility_name_id', '302660_5cd4d54524720')->references('id')->on('facilities')->onDelete('cascade');
                }
                
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('events', function(Blueprint $table) {
            
        });
    }
}
