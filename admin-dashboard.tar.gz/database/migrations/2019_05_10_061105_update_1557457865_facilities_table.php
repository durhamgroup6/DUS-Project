<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Update1557457865FacilitiesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('facilities', function (Blueprint $table) {
            if(Schema::hasColumn('facilities', 'facility_phone')) {
                $table->dropColumn('facility_phone');
            }
            
        });
Schema::table('facilities', function (Blueprint $table) {
            
if (!Schema::hasColumn('facilities', 'facility_phone')) {
                $table->string('facility_phone')->nullable();
                }
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('facilities', function (Blueprint $table) {
            $table->dropColumn('facility_phone');
            
        });
Schema::table('facilities', function (Blueprint $table) {
                        $table->integer('facility_phone')->nullable();
                
        });

    }
}
