<?php

namespace App\Providers;

use App\Role;
use App\User;
use Illuminate\Support\Facades\Gate;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        $user = \Auth::user();

        
        // Auth gates for: User management
        Gate::define('user_management_access', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Users
        Gate::define('user_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('user_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Facility
        Gate::define('facility_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('facility_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('facility_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('facility_view', function ($user) {
            return in_array($user->role_id, [1, 2, 3]);
        });
        Gate::define('facility_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

        // Auth gates for: Events
        Gate::define('event_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('event_create', function ($user) {
            return in_array($user->role_id, [1, 3]);
        });
        Gate::define('event_edit', function ($user) {
            return in_array($user->role_id, [1, 3]);
        });
        Gate::define('event_view', function ($user) {
            return in_array($user->role_id, [1, 2, 3]);
        });
        Gate::define('event_delete', function ($user) {
            return in_array($user->role_id, [1, 3]);
        });

        // Auth gates for: Booking
        Gate::define('booking_access', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('booking_create', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('booking_edit', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('booking_view', function ($user) {
            return in_array($user->role_id, [1]);
        });
        Gate::define('booking_delete', function ($user) {
            return in_array($user->role_id, [1]);
        });

    }
}
