<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Facility
 *
 * @package App
 * @property string $facility_name
 * @property string $picture
 * @property integer $availbility
 * @property text $description
 * @property string $adderss
 * @property integer $capacity
 * @property string $facility_email
 * @property string $facility_phone
*/
class Facility extends Model
{
    use SoftDeletes;

    protected $fillable = ['facility_name', 'picture', 'availbility', 'description', 'capacity', 'facility_email', 'facility_phone', 'adderss_address', 'adderss_latitude', 'adderss_longitude'];
    protected $hidden = [];
    
    

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setAvailbilityAttribute($input)
    {
        $this->attributes['availbility'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setCapacityAttribute($input)
    {
        $this->attributes['capacity'] = $input ? $input : null;
    }
    
}
