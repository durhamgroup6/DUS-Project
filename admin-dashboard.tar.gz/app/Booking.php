<?php
namespace App;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Class Booking
 *
 * @package App
 * @property string $user_name
 * @property string $event_name
 * @property string $facility_name
 * @property integer $quantity
 * @property decimal $price
 * @property string $booking_date
*/
class Booking extends Model
{
    use SoftDeletes;

    protected $fillable = ['quantity', 'price', 'booking_date', 'user_name_id', 'event_name_id', 'facility_name_id'];
    protected $hidden = [];
    
    

    /**
     * Set to null if empty
     * @param $input
     */
    public function setUserNameIdAttribute($input)
    {
        $this->attributes['user_name_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setEventNameIdAttribute($input)
    {
        $this->attributes['event_name_id'] = $input ? $input : null;
    }

    /**
     * Set to null if empty
     * @param $input
     */
    public function setFacilityNameIdAttribute($input)
    {
        $this->attributes['facility_name_id'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setQuantityAttribute($input)
    {
        $this->attributes['quantity'] = $input ? $input : null;
    }

    /**
     * Set attribute to money format
     * @param $input
     */
    public function setPriceAttribute($input)
    {
        $this->attributes['price'] = $input ? $input : null;
    }

    /**
     * Set attribute to date format
     * @param $input
     */
    public function setBookingDateAttribute($input)
    {
        if ($input != null && $input != '') {
            $this->attributes['booking_date'] = Carbon::createFromFormat(config('app.date_format'), $input)->format('Y-m-d');
        } else {
            $this->attributes['booking_date'] = null;
        }
    }

    /**
     * Get attribute from date format
     * @param $input
     *
     * @return string
     */
    public function getBookingDateAttribute($input)
    {
        $zeroDate = str_replace(['Y', 'm', 'd'], ['0000', '00', '00'], config('app.date_format'));

        if ($input != $zeroDate && $input != null) {
            return Carbon::createFromFormat('Y-m-d', $input)->format(config('app.date_format'));
        } else {
            return '';
        }
    }
    
    public function user_name()
    {
        return $this->belongsTo(User::class, 'user_name_id');
    }
    
    public function event_name()
    {
        return $this->belongsTo(Event::class, 'event_name_id')->withTrashed();
    }
    
    public function facility_name()
    {
        return $this->belongsTo(Facility::class, 'facility_name_id')->withTrashed();
    }
    
}
