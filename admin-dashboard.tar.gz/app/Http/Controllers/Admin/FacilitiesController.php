<?php

namespace App\Http\Controllers\Admin;

use App\Facility;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreFacilitiesRequest;
use App\Http\Requests\Admin\UpdateFacilitiesRequest;
use App\Http\Controllers\Traits\FileUploadTrait;

class FacilitiesController extends Controller
{
    use FileUploadTrait;

    /**
     * Display a listing of Facility.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (! Gate::allows('facility_access')) {
            return abort(401);
        }


        if (request('show_deleted') == 1) {
            if (! Gate::allows('facility_delete')) {
                return abort(401);
            }
            $facilities = Facility::onlyTrashed()->get();
        } else {
            $facilities = Facility::all();
        }

        return view('admin.facilities.index', compact('facilities'));
    }

    /**
     * Show the form for creating new Facility.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if (! Gate::allows('facility_create')) {
            return abort(401);
        }
        return view('admin.facilities.create');
    }

    /**
     * Store a newly created Facility in storage.
     *
     * @param  \App\Http\Requests\StoreFacilitiesRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreFacilitiesRequest $request)
    {
        if (! Gate::allows('facility_create')) {
            return abort(401);
        }
        $request = $this->saveFiles($request);
        $facility = Facility::create($request->all());



        return redirect()->route('admin.facilities.index');
    }


    /**
     * Show the form for editing Facility.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        if (! Gate::allows('facility_edit')) {
            return abort(401);
        }
        $facility = Facility::findOrFail($id);

        return view('admin.facilities.edit', compact('facility'));
    }

    /**
     * Update Facility in storage.
     *
     * @param  \App\Http\Requests\UpdateFacilitiesRequest  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateFacilitiesRequest $request, $id)
    {
        if (! Gate::allows('facility_edit')) {
            return abort(401);
        }
        $request = $this->saveFiles($request);
        $facility = Facility::findOrFail($id);
        $facility->update($request->all());



        return redirect()->route('admin.facilities.index');
    }


    /**
     * Display Facility.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        if (! Gate::allows('facility_view')) {
            return abort(401);
        }
        $bookings = \App\Booking::where('facility_name_id', $id)->get();$events = \App\Event::where('facility_name_id', $id)->get();

        $facility = Facility::findOrFail($id);

        return view('admin.facilities.show', compact('facility', 'bookings', 'events'));
    }


    /**
     * Remove Facility from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        if (! Gate::allows('facility_delete')) {
            return abort(401);
        }
        $facility = Facility::findOrFail($id);
        $facility->delete();

        return redirect()->route('admin.facilities.index');
    }

    /**
     * Delete all selected Facility at once.
     *
     * @param Request $request
     */
    public function massDestroy(Request $request)
    {
        if (! Gate::allows('facility_delete')) {
            return abort(401);
        }
        if ($request->input('ids')) {
            $entries = Facility::whereIn('id', $request->input('ids'))->get();

            foreach ($entries as $entry) {
                $entry->delete();
            }
        }
    }


    /**
     * Restore Facility from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function restore($id)
    {
        if (! Gate::allows('facility_delete')) {
            return abort(401);
        }
        $facility = Facility::onlyTrashed()->findOrFail($id);
        $facility->restore();

        return redirect()->route('admin.facilities.index');
    }

    /**
     * Permanently delete Facility from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function perma_del($id)
    {
        if (! Gate::allows('facility_delete')) {
            return abort(401);
        }
        $facility = Facility::onlyTrashed()->findOrFail($id);
        $facility->forceDelete();

        return redirect()->route('admin.facilities.index');
    }
}
