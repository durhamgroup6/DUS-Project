<?php
namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;

class StoreFacilitiesRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'facility_name' => 'required|unique:facilities,facility_name,'.$this->route('facility'),
            'picture' => 'nullable|mimes:png,jpg,jpeg,gif',
            'availbility' => 'max:1|required|numeric',
            'capacity' => 'min:1|max:2147483647|nullable|numeric',
            'facility_email' => 'email',
        ];
    }
}
